<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/letters/0">Letters</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/senders/0">Senders</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/transport">Transport</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/log">Log</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/queue">Queue</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/spam_lists">Spam lists</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/fbl">FBL reports</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/settings">Settings</a></li>