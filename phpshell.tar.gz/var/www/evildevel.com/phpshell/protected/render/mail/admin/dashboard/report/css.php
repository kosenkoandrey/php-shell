<style>
    .mail_queue_sample {}
</style>