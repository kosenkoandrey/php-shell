<aside id="s-main-menu" class="sidebar">
    <div class="smm-header">
        <i class="zmdi zmdi-long-arrow-left" data-ma-action="sidebar-close"></i>
    </div>

    <ul class="main-menu">
        <li>
            <a href="<?= APP::Module('Routing')->root ?>link1"><i class="zmdi zmdi-caret-right"></i> Link1</a>
            <a href="<?= APP::Module('Routing')->root ?>link2"><i class="zmdi zmdi-caret-right"></i> Link2</a>
            <a href="<?= APP::Module('Routing')->root ?>link3"><i class="zmdi zmdi-caret-right"></i> Link3</a>
        </li>
    </ul>
</aside>