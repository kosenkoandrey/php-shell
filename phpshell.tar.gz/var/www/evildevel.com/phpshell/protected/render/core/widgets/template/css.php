<style>
    body:before {
        height: 139px !important;
    }
    
    #header {
        margin-bottom: 30px !important;
    }
</style>