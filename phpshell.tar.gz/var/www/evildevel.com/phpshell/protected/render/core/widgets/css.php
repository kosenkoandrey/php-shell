<?
APP::$insert['core_css_1'] = ['css', 'file', 'before', '</body>', APP::$conf['location'][0] . '://' . APP::$conf['location'][1] . APP::$conf['location'][2] . 'public/ui/css/app.min.1.css'];
APP::$insert['core_css_2'] = ['css', 'file', 'before', '</body>', APP::$conf['location'][0] . '://' . APP::$conf['location'][1] . APP::$conf['location'][2] . 'public/ui/css/app.min.2.css'];