<li><a href="<?= APP::Module('Routing')->root ?>admin/comments">Messages</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/comments/objects">Objects</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/comments/settings">Settings</a></li>