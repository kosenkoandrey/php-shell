<?
APP::$insert['css_datetimepicker'] = ['css', 'file', 'before', '</head>', APP::Module('Routing')->root . 'public/ui/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css'];
?>
<style>
    #likes-chart {
        width: 100%;
	height: 300px;
	font-size: 14px;
	line-height: 1.2em;
    }
</style>