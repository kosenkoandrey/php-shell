<li><a href="<?= APP::Module('Routing')->root ?>admin/likes">List</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/likes/objects">Objects</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/likes/settings">Settings</a></li>