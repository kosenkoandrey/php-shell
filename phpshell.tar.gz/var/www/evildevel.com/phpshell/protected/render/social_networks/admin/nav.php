<li><a href="<?= APP::Module('Routing')->root ?>admin/social_networks">Overview</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/social_networks/settings">Settings</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/social_networks/other">Other</a></li>