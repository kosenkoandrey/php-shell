<html>
    <head>
        <script src="<?= APP::Module('Routing')->root ?>public/ui/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    </head>
    <body>
        <h1>Ваша оценка и комментарий были сохранены ранее</h1>
        
    </body>
</html>