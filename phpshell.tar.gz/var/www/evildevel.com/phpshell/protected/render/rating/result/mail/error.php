<html>
    <head>
        <script src="<?= APP::Module('Routing')->root ?>public/ui/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    </head>
    <body>
        <h1>Ошибка определения объекта</h1>
        
    </body>
</html>