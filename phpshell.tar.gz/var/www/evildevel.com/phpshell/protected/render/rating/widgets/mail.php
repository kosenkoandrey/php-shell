<div style="padding:5px 0;">
    How do you like today's letter?
    <br>
    <a href="<?= APP::Module('Routing')->root ?>rating/mail/1/[letter_hash]" style="display:inline-block;width:30px;height:30px;margin-top:8px;"><img src="<?= APP::Module('Routing')->root ?>public/modules/rating/emotions/1.png" style="border: 0"></a>&nbsp;&nbsp;
    <a href="<?= APP::Module('Routing')->root ?>rating/mail/2/[letter_hash]" style="display:inline-block;width:30px;height:30px;margin-top:8px;"><img src="<?= APP::Module('Routing')->root ?>public/modules/rating/emotions/2.png" style="border: 0"></a>&nbsp;&nbsp;
    <a href="<?= APP::Module('Routing')->root ?>rating/mail/3/[letter_hash]" style="display:inline-block;width:30px;height:30px;margin-top:8px;"><img src="<?= APP::Module('Routing')->root ?>public/modules/rating/emotions/3.png" style="border: 0"></a>&nbsp;&nbsp;
    <a href="<?= APP::Module('Routing')->root ?>rating/mail/4/[letter_hash]" style="display:inline-block;width:30px;height:30px;margin-top:8px;"><img src="<?= APP::Module('Routing')->root ?>public/modules/rating/emotions/4.png" style="border: 0"></a>&nbsp;&nbsp;
    <a href="<?= APP::Module('Routing')->root ?>rating/mail/5/[letter_hash]" style="display:inline-block;width:30px;height:30px;margin-top:8px;"><img src="<?= APP::Module('Routing')->root ?>public/modules/rating/emotions/5.png" style="border: 0"></a>&nbsp;&nbsp;
</div>