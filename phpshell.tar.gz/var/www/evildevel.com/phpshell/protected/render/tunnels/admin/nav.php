<li><a href="<?= APP::Module('Routing')->root ?>admin/tunnels">Manage</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/tunnels/settings">Settings</a></li>