<li><a href="<?= APP::Module('Routing')->root ?>admin/taskmanager">Tasks</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/taskmanager/settings">Settings</a></li>