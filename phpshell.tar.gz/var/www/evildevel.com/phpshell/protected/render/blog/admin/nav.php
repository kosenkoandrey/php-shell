<li><a href="<?= APP::Module('Routing')->root ?>admin/blog/articles/0">Articles</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/blog/settings">Settings</a></li>