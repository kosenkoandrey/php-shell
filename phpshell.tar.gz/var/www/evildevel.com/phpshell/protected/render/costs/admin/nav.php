<li><a href="<?= APP::Module('Routing')->root ?>admin/costs">Manage</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/costs/settings">Settings</a></li>