<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class CryptTest extends TestCase {}