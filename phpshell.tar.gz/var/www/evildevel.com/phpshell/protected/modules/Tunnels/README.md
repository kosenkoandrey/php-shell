# Tunnels


### Dependencies
- [](https://github.com/evildevel/php-shell/tree/master/protected/modules/)

### Files
```
/protected
├── /modules
│   └── /Tunnels
│       ├── MANIFEST
│       ├── README.md
│       ├── class.php
│       ├── conf.php
│       ├── install.php
│       └── uninstall.php
└── /render
```

### Properties
```php

```

### Methods
```php

```

### Triggers
- 

### WEB interfaces
```

```