<?
return [
    'connections' => [
        'auto' => [
            'type'      => 'mysql',
            'host'      => 'localhost',
            'database'  => 'phpshell',
            'username'  => 'root',
            'password'  => 'mnm69i9QZ4ap',
            'charset'   => 'utf8'
        ]
    ],
    'init' => true
];