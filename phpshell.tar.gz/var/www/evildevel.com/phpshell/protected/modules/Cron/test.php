<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class CronTest extends TestCase {}