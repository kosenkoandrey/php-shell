<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class RobotsTXTTest extends TestCase {}