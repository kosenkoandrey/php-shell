<?
return [
    'routes' => [
        ['abc', 'Test', 'ABC'],
        ['parser\/auto.ru', 'Test', 'AutoParser']
    ]
];