<?
class Test {

    function __construct($conf) {
        foreach ($conf['routes'] as $route) APP::Module('Routing')->Add($route[0], $route[1], $route[2]);
    }

    public function ABC() {
        print_r(APP::Module('Mail')->Send('evildevel@mail.ru', 27));
    }
    
    public function Domains() {
        $words = [
            'advance',
            'agent',
            'alive',
            'area',
            'base',
            'bind',
            'board',
            'box',
            'brain',
            'card',
            'cart',
            'case',
            'choice',
            'click',
            'complex',
            'data',
            'dealer',
            'desk',
            'direct',
            'easy',
            'express',
            'extend',
            'extra',
            'fair',
            'filter',
            'find',
            'fine',
            'fit',
            'frame',
            'gate',
            'get',
            'good',
            'grand',
            'here',
            'hero',
            'hit',
            'hold',
            'hot',
            'house',
            'idea',
            'it',
            'its',
            'join',
            'just',
            'lab',
            'land',
            'last',
            'like',
            'line',
            'link',
            'magic',
            'main',
            'make',
            'many',
            'map',
            'market',
            'mass',
            'master',
            'mine',
            'mix',
            'my',
            'new',
            'nice',
            'now',
            'on',
            'pad',
            'perfect',
            'pick',
            'pin',
            'place',
            'play',
            'pulse',
            'root',
            'sale',
            'safe',
            'scan',
            'sell',
            'service',
            'shot',
            'smart',
            'space',
            'star',
            'store',
            'style',
            'super',
            'tag',
            'top',
            'total',
            'unit',
            'your',
        ];
        
        $keys = [
            'house'
        ];
        
        /*
        foreach ($words as $word) {
            foreach ($keys as $key) {
                echo $key . $word . "\n";
                echo $word . $key . "\n";
            }
        }
         * 
         */
        
        for ($i = 1; $i <= 99; $i ++) {
            echo $i . "-reg\n";
        }
    }
    
    public function AutoParser() {
        $settings = [
            'category' => 'cars',
            'section' => 'all',
            'pageSession' => '_dd7d8b1c3b3d',
            'serpId' => '1480168714549_186f60cafbb9',
            'sort_offers' => 'fresh_relevance_1-DESC',
            'top_days' => 'off',
            'currency' => 'RUR',
            'output_type' => 'list',
            'image' => 'true',
            'year_from' => '2007',
            'beaten' => '1',
            'customs_state' => '1',
            'page_num_offers' => '1',
            'mark-model-nameplate[]' => 'AUDI#A6##2305417',
            'newUrl' => '/cars/audi/a6/2305417/all/?sort_offers=fresh_relevance_1-DESC&top_days=off&currency=RUR&output_type=list&image=true&year_from=2007&beaten=1&customs_state=1&page_num_offers=1',
            '__blocks' => 'listing-list,service-navigation,tabs_type_listing,dealers-promotion,listing-seo-header,listing-seo-text,listing-seo-title,listing-related,pager-listing,sale-data-attributes,search-button,specials-sales,promo-subscription,search-save',
            'crc' => 'f94fed5fccd87ef9a0ad9ce37aeace26d77ad908:1480168714548'
        ];
        
        $client = [
            'return_transfer' => true,
            'follow_location' => true,
            'header' => true,
            'cookie_file' => '/tmp/cookie',
            'cookie_jar' => '/tmp/cookie',
            'useragent' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
            'autoreferer' => true,
            'fresh_connect' => true,
            'http_version' => CURL_HTTP_VERSION_1_1,
            'http_header' => [
                'Accept' => 'application/json, text/javascript, */*; q=0.01',
                'Accept-Encoding' => 'gzip, deflate, sdch, br',
                'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4',
                'Cache-Control' => 'no-cache',
                'Connection' => 'keep-alive',
                'Host' => 'auto.ru',
                'Pragma' => 'no-cache',
                'Upgrade-Insecure-Requests' => '1'
            ]
        ];
        
        /*
        $showcaptcha = APP::Module('Utils')->Curl(array_merge($client, [
            'url' => 'https://auto.ru/showcaptcha?retpath=https%3A//auto.ru/%3F_405e01e50f064ba0e45be60bbdcfcf56&t=0/1480183329/2ca7c97ae5f82570f70c8098250bf846&s=541c7c6a6a4dec098585a90ddaf7c689',
            'cookie_jar' => '/tmp/cookie'
        ]));
        
        echo $showcaptcha; exit;
        
        $checkcaptcha = APP::Module('Utils')->Curl(array_merge($client, [
            'url' => 'https://auto.ru/checkcaptcha?key=' . urlencode('c3BlqYlHsEhofTy8ifd8OPyFx6WRa9zm_0/1480183329/2ca7c97ae5f82570f70c8098250bf846_f166299fdbe914f34d10c2e07da7d571') . '&retpath=' . urlencode('https://auto.ru/?_405e01e50f064ba0e45be60bbdcfcf56') . '&rep=' . urlencode('тирана') . '',
            'cookie_file' => '/tmp/cookie',
            'cookie_jar' => '/tmp/cookie'
        ]));
        
        echo $checkcaptcha; exit;
        

        $index = APP::Module('Utils')->Curl(array_merge($client, [
            'url' => 'https://auto.ru/?_405e01e50f064ba0e45be60bbdcfcf56',
            'cookie_file' => '/tmp/cookie',
            'cookie_jar' => '/tmp/cookie'
        ]));
        
        echo $index; exit;
        */
        $listing = APP::Module('Utils')->Curl(array_merge($client, [
            'url' => 'https://www.avito.ru/perm/avtomobili/audi/a6?f=188_899b900',
            'cookie_file' => '/tmp/cookie',
            'cookie_jar' => '/tmp/cookie'
        ]));
        
        echo $listing; exit;
        
        $decode_listing = json_decode($listing);
        print_r($decode_listing);
    }
    
}