<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class CacheTest extends TestCase {}