<?
$data->extractTo(ROOT);