<?
APP::Module('Triggers')->Unregister([
    'import_locale_module',
    'remove_imported_module',
    'export_module',
    'uninstall_module'
]);