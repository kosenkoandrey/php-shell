<?
return [
    'routes' => [],
    'init' => true
];