<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class RoutingTest extends TestCase {}